window.onload = function() {
  const img = document.getElementById("day-night-image");
  const hour = new Date().getHours();

  if (hour <= 17) {
    img.src = "assets/sun.png";
    img.alt = "Sun";
  } else {
    img.src = "assets/moon.png";
    img.alt = "Moon";
  }

  img.style.display = "block"; // show image on load
};

function showImage() {
  document.getElementById("day-night-image").style.display = "block";
}

function hideImage() {
  document.getElementById("day-night-image").style.display = "none";
}

function increaseFont() {
  const title = document.getElementById("page-title");
  let style = window.getComputedStyle(title, null).getPropertyValue('font-size');
  let currentSize = parseFloat(style);
  title.style.fontSize = (currentSize + 2) + "px";
}

function decreaseFont() {
  const title = document.getElementById("page-title");
  let style = window.getComputedStyle(title, null).getPropertyValue('font-size');
  let currentSize = parseFloat(style);
  title.style.fontSize = (currentSize - 2) + "px";
}